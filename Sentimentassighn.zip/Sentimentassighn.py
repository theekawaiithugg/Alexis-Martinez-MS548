import requests
from bs4 import BeautifulSoup
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
import tkinter as tk
from tkinter import scrolledtext, font

class SentimentAnalyzerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Website Sentiment Analyzer")
        self.root.configure(bg='light blue')  # Setting background color of the window
        
        # Custom font
        self.custom_font = font.Font(family='Helvetica', size=12)

        # Label for URL entry
        self.label = tk.Label(root, text="Enter Website URL:", bg='light blue', fg='black', font=self.custom_font)
        self.label.pack(pady=10)

        # URL entry
        self.url_entry = tk.Entry(root, width=50, font=self.custom_font)
        self.url_entry.pack(pady=10)
        
        # Label for Subject
        self.label = tk.Label(root, text="Enter Subject:", bg='light blue', fg='black', font=self.custom_font) 
        self.label.pack(pady=10)        

        # Subject entry
        self.Subject_entry = tk.Entry(root, width=30, font=self.custom_font)
        self.Subject_entry.pack(pady=10)
        
        # Analyze Button
        self.analyze_button = tk.Button(root, text="Analyze Sentiment", command=self.perform_analysis, bg='navy', fg='white', font=self.custom_font)
        self.analyze_button.pack(pady=10)

        # Text box for results
        self.result_text = scrolledtext.ScrolledText(root, width=60, height=10, font=self.custom_font)
        self.result_text.pack(pady=10)

    def extract_website_text(self, url):
        response = requests.get(url)
        soup = BeautifulSoup(response.content, 'html.parser')
        article_text = ''
        for paragraph in soup.find_all('p'):
            article_text += paragraph.text.strip() + ' '
        return article_text

    def analyze_sentiment(self, text):
        analyzer = SentimentIntensityAnalyzer()
        sentiment_score = analyzer.polarity_scores(text)
        compound_score = sentiment_score['compound']
        sentiment_label = "positive" if compound_score >= 0 else "negative"
        return compound_score, sentiment_label

    def perform_analysis(self):
        url = self.url_entry.get()
        subjectz = self.Subject_entry.get()
        text = self.extract_website_text(url)
        compound_score, sentiment_label = self.analyze_sentiment(text)

        # Display the results
        self.result_text.delete('1.0', tk.END)
        self.result_text.insert(tk.END, f"Sentiment Analysis Results for {subjectz}:\n")
        self.result_text.insert(tk.END, f"Compound Score: {compound_score}\n")
        self.result_text.insert(tk.END, f"Sentiment Label: {sentiment_label}\n")

# Create the main window and pass it to the SentimentAnalyzerApp class
root = tk.Tk()
app = SentimentAnalyzerApp(root)
root.mainloop()
