import tkinter as tk
from tkinter import ttk, scrolledtext, filedialog, messagebox
from collections import Counter
from textblob import TextBlob
import re
from datetime import datetime
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg  import FigureCanvasTkAgg
import numpy as np


class FileOperations:
    @staticmethod
    def open_txt():
        try:
            entries = []
            with open("userzdata.txt", "r") as file:
                for line in file:
                    try:
                        parts = line.strip().split(" - ", 3)  # Split into four parts
                        if len(parts) < 4:
                            print(f"Skipping line due to incorrect format: {line}")
                            continue
                        date, name, text, sentiment = parts
                        entries.append({"date": date, "name": name, "text": text, "sentiment": sentiment})
                    except ValueError:
                        print(f"Skipping line due to incorrect format: {line}")
            return entries
        except FileNotFoundError:
            print("The file userzdata.txt was not found.")
            return []

class TextProcessing:
    @staticmethod
    def sentiment_analysis(text):
        blob = TextBlob(text)
        sentiment = blob.sentiment
        return f"Polarity: {sentiment.polarity}, Subjectivity: {sentiment.subjectivity}"

    @staticmethod
    def word_frequency(text):
        blob = TextBlob(text)
        words = blob.words.lower()
        word_freq = Counter(words)
        common_words = word_freq.most_common(3)
        return "\n".join([f"{word}: {freq}" for word, freq in common_words])

    @staticmethod
    def spelling_correction(text):
        blob = TextBlob(text)
        corrected = blob.correct()
        return f"Corrected text: {corrected}"

    @staticmethod
    def text_summarization(text):
        blob = TextBlob(text)
        sentences = blob.sentences
        summary = sentences[:2]
        return '\n'.join(str(sentence) for sentence in summary)
    @staticmethod
    def average_sentiment(entries):
        total_polarity = 0
        count = len(entries)
        for entry in entries:
            blob = TextBlob(entry['text'])
            total_polarity += blob.sentiment.polarity
        average_polarity = total_polarity / count if count else 0
        return average_polarity
   
    @staticmethod
    def average_sentiment_by_user(entries):
        # Organize entries by user
        user_entries = {}
        for entry in entries:
            user = entry['name']
            if user not in user_entries:
                user_entries[user] = []
            user_entries[user].append(entry['text'])
        
        # Calculate average sentiment for each user
        average_sentiments = {}
        for user, texts in user_entries.items():
            total_polarity = 0
            for text in texts:
                blob = TextBlob(text)
                total_polarity += blob.sentiment.polarity
            average_polarity = total_polarity / len(texts) if texts else 0
            average_sentiments[user] = average_polarity
        
        return average_sentiments

class MoodTrackerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Mood Tracker Prototype")
        self.inputs_storage = {}
        self.diary_entries = []  # Initialize diary_entries as an empty list
        self.create_widgets()  # Ensure widgets are created first
        self.load_entries_from_file()  # Load entries and update diary_entries

    def open_existing_entries(self):
        entries = FileOperations.open_txt()
        results_text = "\n\n".join([f"{entry['date']}\n{entry['name']}\n{entry['text']}" for entry in entries])
        self.display_results(results_text)
        return entries
    
    def save_entry(self):
        self.inputs_storage = {
        "Name": self.entries['Name'].get().strip(),
        "Email": self.entries['Email'].get().strip(),
        "Date": self.entries['Date'].get().strip(),
        "Text Input": self.text_input.get("1.0", tk.END).strip()
         }

        # Perform validation checks
        if not self.inputs_storage["Name"]:
            messagebox.showerror("Validation Error", "Name cannot be empty.")
            return
        if not re.match(r'^[\w\.-]+@[\w\.-]+\.\w+$', self.inputs_storage["Email"]):
            messagebox.showerror("Validation Error", "Invalid email format.")
            return
        try:
            datetime.strptime(self.inputs_storage["Date"], '%Y-%m-%d')
        except ValueError:
            messagebox.showerror("Validation Error", "Please use YYYY-MM-DD format for the date.")
            return

        # Once validation passes, proceed with sentiment analysis and saving
        sentiment_text = TextProcessing.sentiment_analysis(self.inputs_storage["Text Input"])
        entry_text = f"{self.inputs_storage['Date']} - {self.inputs_storage['Name']} - {self.inputs_storage['Text Input']} - {sentiment_text}\n"
        
        try:
            with open("userzdata.txt", "a") as file:
                file.write(entry_text)
            self.display_results("Entry saved.")
        except Exception as e:
            print(f"Error occurred while saving entry: {e}")
            messagebox.showerror("Save Error", "Failed to save entry.")

    def create_widgets(self):
         # Create labels and entry fields
        self.entries = {
            "Name": tk.StringVar(),
            "Email": tk.StringVar(),
            "Date": tk.StringVar()
        }
        row = 0
        for label, var in self.entries.items():
            ttk.Label(self.root, text=f"{label}:").grid(column=0, row=row, padx=10, pady=5, sticky='W')
            ttk.Entry(self.root, textvariable=var).grid(column=1, row=row, padx=10, pady=5, sticky='WE')
            row += 1
        pass

        # Operation Selection
        self.operation = tk.StringVar()
        operations = ['Sentiment Analysis', 'Word Frequency', 'Spelling Correction', 'Text Summarization']
        ttk.Label(self.root, text="Select Operation:").grid(column=0, row=row, padx=10, pady=5)
        self.operation_combo = ttk.Combobox(self.root, width=20, textvariable=self.operation, state='readonly')
        self.operation_combo['values'] = operations
        self.operation_combo.grid(column=1, row=row, padx=10, pady=5) #row = 0 to row = row
        self.operation_combo.current(0)
        row += 1

        # Text Input Box
        ttk.Label(self.root, text="Input Text:").grid(column=0, row=row, padx=10, pady=5, sticky='NW') #Input text label
        self.text_input = scrolledtext.ScrolledText(self.root, width=40, height=10, wrap=tk.WORD) #this helps us wrap text when typing in box
        self.text_input.grid(column=1, row=row, padx=10, pady=5) 
        row += 1
        
        
        # Results Display Box
        ttk.Label(self.root, text="Results:").grid(column=0, row=row, padx=10, pady=5, sticky='NW')
        self.results_display = scrolledtext.ScrolledText(self.root, width=40, height=10, wrap=tk.WORD, state='disabled')
        self.results_display.grid(column=1, row=row, padx=10, pady=5)
        
        # Submit button
        submit_button = ttk.Button(self.root, text="Save", command=lambda: [ self.save_entry(), self.Operaterw()])
        submit_button.grid(column=0, row=row+1, columnspan=2, padx=10, pady=10)

        #File Button
        file_button = ttk.Button(self.root, text="File", command=self.load_entries_from_file)
        file_button.grid(column=2, row=row + 1, columnspan=2, padx=10, pady=10)
        
        #Stats Button
        stats_button = ttk.Button(self.root, text="Show Statistics", command=self.show_statistics)
        stats_button.grid(column=2, row=0, padx=10, pady=10)  # Adjust placement accordingly

    def load_entries_from_file(self):
        self.diary_entries = FileOperations.open_txt()  # Load and update diary_entries
        entries_text = "\n\n".join([f"{entry['date']} - {entry['name']} - {entry['text']} - {entry['sentiment']}" for entry in self.diary_entries])
        self.display_results(entries_text)
        

    def Operaterw(self):
        # Modify this method to call the appropriate methods from TextProcessing based on the selected operation
        
        operation = self.operation.get()
        text = self.text_input.get("1.0", tk.END).strip()
        result = ""

        if operation == 'Sentiment Analysis':
            result = TextProcessing.sentiment_analysis(text)
        elif operation == 'Word Frequency':
            result = TextProcessing.word_frequency(text)
        elif operation == 'Spelling Correction':
            result = TextProcessing.spelling_correction(text)
        elif operation == 'Text Summarization':
            result = TextProcessing.text_summarization(text)

        if isinstance(result, list):
            # If the result is a list, assume it's in the format [result_string, data]
            entries = result[1]  # Extract the data from the result
        else:
            # If the result is a string, create a single-entry list with the text input
            entries = [{"date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "text": result}]

        self.display_results(result)
        
    
    def sentiment_analysis(self, text):
        blob = TextBlob(text)
        sentiment = blob.sentiment
        return [f"Sentiment polarity: {sentiment.polarity}, Sentiment subjectivity: {sentiment.subjectivity}", sentiment]
    
    def Word_Frequency(self, text):
        blob = TextBlob(text)
        words = blob.words.lower()  # Convert to lowercase to ensure accurate frequency analysis
        word_freq = Counter(words)
        # Display the most common 3 words and their frequencies
        common_words = word_freq.most_common(3)
        return [f"Word Frequencies:\n" + "\n".join([f"{word}: {freq}" for word, freq in common_words]), common_words]
    
    def spelling_correction(self, text):
        blob = TextBlob(text)
        corrected = blob.correct()
        return [f"Corrected text: {corrected}", corrected]
    
    def text_summarization(self, text):
        blob = TextBlob(text)
        sentences = blob.sentences
        summary = sentences[:2]  # Simple strategy: take the first two sentences as a summary
        return ['\n'.join(str(sentence) for sentence in summary), summary]
    
    def display_results(self, text):
        self.results_display.config(state='normal')  # Enable text widget
        self.results_display.delete('1.0', tk.END)  # Clear existing content
        self.results_display.insert('1.0', text)  # Insert new text
        self.results_display.config(state='disabled')  # Disable text widget to prevent editing

    

    def validate_email(self, email):
        """Basic email validation."""
        pattern = r'^[\w\.-]+@[\w\.-]+\.\w+$'
        return re.match(pattern, email) is not None

    def validate_date(self, date_text):
        """Validate date format YYYY-MM-DD."""
        try:
            datetime.strptime(date_text, '%Y-%m-%d')
            return True
        except ValueError:
            return False
    

    def show_statistics(self):
        # Ensure diary_entries is used to calculate statistics
        if not self.diary_entries:  # Check if diary_entries is empty
            messagebox.showinfo("Statistics", "No data available.")
            return

        average_polarity = TextProcessing.average_sentiment(self.diary_entries)
        average_sentiments = TextProcessing.average_sentiment_by_user(self.diary_entries)
        print("Average Polarity:", average_polarity)
        print("Average Sentiments by User:", average_sentiments)

        # Create a new window for statistics
        stats_window = tk.Toplevel(self.root)
        stats_window.title("Statistics")
        
        # Calculate statistics
        average_polarity = TextProcessing.average_sentiment(self.diary_entries)
        # Calculate average sentiment by user
        average_sentiments = TextProcessing.average_sentiment_by_user(self.diary_entries)
        
        # Debug: Print averages to ensure data is loaded
        print("Average Polarity:", average_polarity)
        print("Average Sentiments by User:", average_sentiments)

        if not average_sentiments:  # Check if there are any user sentiments to plot
            ttk.Label(stats_window, text="No data to display.").pack(pady=10)
            return

        # Prepare data for plotting
        users = list(average_sentiments.keys())
        average_polarities = list(average_sentiments.values())
        
        # Display average polarity
        ttk.Label(stats_window, text=f"Average Sentiment Polarity: {average_polarity:.2f}").pack(pady=10)
        
        # Create matplotlib figure
        fig = plt.figure(figsize=(10,4), dpi=100)
        plot = fig.add_subplot(1, 1, 1)
        
        # Plot the data
        plot.bar(users, average_polarities, color='skyblue')
        plot.set_xlabel('User')
        plot.set_ylabel('Average Sentiment Polarity')
        plot.set_title('Average Sentiment Polarity by User')
        plot.set_xticks(range(len(users)))  # Set the x-ticks positions
        plot.set_xticklabels(users, rotation=45, ha="right") # Set the labels after defining positions
        
        # Create a canvas and add the plot to the Tkinter window
        canvas = FigureCanvasTkAgg(fig, master=stats_window)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=1)

def main():
    root = tk.Tk()
    app = MoodTrackerApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
