import tensorflow as tf
from tensorflow import keras
from sklearn.model_selection import train_test_split
from sklearn.datasets import load_iris
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score
import tkinter as tk

def iris_Test():
    #4 features: sepal length, sepal width, petal length, and petal width, classified into 3 types of iris species.
    # Load the Iris dataset
    iris = load_iris()
    X, y = iris.data, iris.target

    # Split the dataset into training and testing sets
    #test size 20% :. training set is 80%; RNG
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.5, random_state=42)#that divides the dataset into two parts: one for training the model and one for testing it.

    # Normalize the features
    scaler = StandardScaler() #normalizes/standardizes the features
    X_train_scaled = scaler.fit_transform(X_train) #computes the mean and standard deviation used for later scaling and scales the training data
    X_test_scaled = scaler.transform(X_test)  #used on the test data to apply the same transformation based on the training data

    # Build a simple neural network model
    model = keras.Sequential([
        keras.layers.Dense(10, activation='relu', input_shape=(X_train_scaled.shape[1],)),#linear stack of layers.
        keras.layers.Dense(8, activation='relu'), #fully connected neural layer
        keras.layers.Dense(3, activation='softmax')
    ])

    model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])

    # Train the model
    model.fit(X_train_scaled, y_train, epochs=100, batch_size=10, verbose=0)

    # Evaluate the model
    predictions = model.predict(X_test_scaled)
    predicted_classes = tf.argmax(predictions, axis=1)
    accuracy = accuracy_score(y_test, predicted_classes.numpy())  # Correct conversion to numpy

    # Update the GUI with the accuracy
    result_label.config(text=f"Model accuracy on the test set: {accuracy * 100:.5f}%")
   
    # Display the test samples and their predicted labels
    samples_text.delete(1.0, tk.END)  # Clear previous content
    for i, (features, true_label) in enumerate(zip(X_test, y_test)):
        predicted_label = predicted_classes[i]
        samples_text.insert(tk.END, f"Sample {i+1}: Features: {features}, True Label: {true_label}, Predicted: {predicted_label}\n")



#create the window
window = tk.Tk()
window.title("Iris Test")

# Create a button to start the test
plot_button = tk.Button(window, text="Run Iris Test", command=iris_Test)
plot_button.pack()

# Create a label to display the result
result_label = tk.Label(window, text="Run the test to see the accuracy")
result_label.pack()

# Create a text widget to display samples and predictions
samples_text = tk.Text(window, height=15, width=80)
samples_text.pack()

# Create a scrollbar for the text widget
scroll = tk.Scrollbar(window, command=samples_text.yview)
scroll.pack(side=tk.RIGHT, fill=tk.Y)
samples_text.config(yscrollcommand=scroll.set)


window.mainloop()
