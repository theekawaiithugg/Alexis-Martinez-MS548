import pandas as pd
import numpy as np
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from sklearn.model_selection import train_test_split

from sklearn.preprocessing import StandardScaler

# Load the dataset
data_path = "snakescores_clean.csv"
data = pd.read_csv(data_path)
# Display the first few rows of the dataframe to inspect its structure and columns
data.head()
#Define column names based on the expected structure
column_names = ['Timestamp', 'PlayerName', 'Score', 'SnakeLength', 'DistanceToFood', 'ScoreIncrease']

# Load the dataset again with explicit column names
data = pd.read_csv(data_path, names=column_names)

# Display the first few rows to confirm the structure
data.head()
# Ensure the correct columns are used
print("Columns in the dataset:", data.columns.tolist())

# For the features, use 'SnakeLength', 'DistanceToFood', and 'ScoreIncrease'
X = data[['SnakeLength', 'DistanceToFood', 'ScoreIncrease']].values  # Use .values to get NumPy array

# The target variable is 'Score'
y = data['Score'].values  # Use .values to get NumPy array

# Splitting the dataset into training and testing set
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Normalize features
scaler = StandardScaler().fit(X_train)
X_train_scaled = scaler.transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Define model
model = Sequential([
    Dense(64, activation='relu', input_shape=(X_train_scaled.shape[1],)),
    Dense(64, activation='relu'),
    Dense(1)
])

model.compile(optimizer='adam', loss='mse')

# Fit the model
model.fit(X_train_scaled, y_train, validation_split=0.2, epochs=100)

# Evaluate the model using the test set
mse = model.evaluate(X_test_scaled, y_test)
print(f"Test MSE: {mse}")

# Predicting the score for a new set of values 
new_values_scaled = scaler.transform(np.array([[10, 5, 2]]))  # Scaling the input
predicted_score = model.predict(new_values_scaled)
print("Predicted Score:", predicted_score[0][0])