import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
import numpy as np

# Load the dataset
data_path = "snakescores_clean.csv"
data = pd.read_csv(data_path)

# Display the first few rows of the dataframe to inspect its structure and columns
data.head()
#Define column names based on the expected structure
column_names = ['Timestamp', 'PlayerName', 'Score', 'SnakeLength', 'DistanceToFood', 'ScoreIncrease']

# Load the dataset again with explicit column names
data = pd.read_csv(data_path, names=column_names)

# Display the first few rows to confirm the structure
data.head()
# Ensure the correct columns are used
print("Columns in the dataset:", data.columns.tolist())

# For the features, we'll use 'SnakeLength', 'DistanceToFood', and 'ScoreIncrease'
X = data[['SnakeLength', 'DistanceToFood', 'ScoreIncrease']]  

# The target variable is 'Score'
y = data['Score']  

# Splitting the dataset into training and testing set
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Initialize the model
model = LinearRegression()

# Fit the model
model.fit(X_train, y_train)

# Predictions
predictions = model.predict(X_test)

# Evaluate the model
mse = mean_squared_error(y_test, predictions)
rmse = np.sqrt(mse)

print("Root Mean Squared Error: ", rmse)

# Predicting the score for a new set of values
# For example: snake_length = 10, distance_to_food = 5, score_increase = 2
new_values = np.array([[10, 5, 2]])  # Must convert list to NumPy array or DataFrame
predicted_score = model.predict(new_values)
print("Predicted Score: ", predicted_score[0])

def predict_future_score(snake_length, game_duration):
    # This function predicts the future score based on the current snake length and game duration
    # Convert snake_length and game_duration to a suitable format for prediction (e.g., a DataFrame)
    # Ensure these match the model's expected input format
    prediction_input = pd.DataFrame([[snake_length, game_duration]], columns=['snake_length', 'game_duration'])
    future_score = model.predict(prediction_input)
    return future_score[0]
