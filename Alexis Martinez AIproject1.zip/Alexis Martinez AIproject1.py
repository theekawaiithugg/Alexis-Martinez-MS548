import tkinter as tk
from tkinter import ttk, scrolledtext
from collections import Counter  # Import needed for word frequency analysis
from textblob import TextBlob
from textblob.exceptions import NotTranslated

#Alexis Cynthia Martinez
#3/13/2024
#9Hours to finish, gui transfer 
#2hours to download textblob and get it working
#making a gui will probably still take longer as I would like to expand on pages and I had trouble before when doing data transfers in C#
#I believe th eonly thing that will be at least a bit less complicating will be using the textblob library again.


class MoodTrackerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Mood Tracker Prototype")
        
        # Dictionary to store the inputs
        self.inputs_storage = {}
        # Create layout
        self.create_widgets()
    
    #This is the actuall widget thingy 
        # i still struggle with padding/grid stuff
    def create_widgets(self): 
        # Create labels and entry fields
        entries = {
            "Name": tk.StringVar(),
            "Email": tk.StringVar(),
            "Date": tk.StringVar()
        }
        row = 0
        for label, var in entries.items():
            ttk.Label(self.root, text=f"{label}:").grid(column=0, row=row, padx=10, pady=5, sticky='W')
            ttk.Entry(self.root, textvariable=var).grid(column=1, row=row, padx=10, pady=5, sticky='WE')
            row += 1


        # Operation Selection
        self.operation = tk.StringVar()
        operations = ['Sentiment Analysis', 'Word Frequency', 'Spelling Correction', 'Text Summarization']
        ttk.Label(self.root, text="Select Operation:").grid(column=0, row=row, padx=10, pady=5)
        self.operation_combo = ttk.Combobox(self.root, width=20, textvariable=self.operation, state='readonly')
        self.operation_combo['values'] = operations
        self.operation_combo.grid(column=1, row=row, padx=10, pady=5) #row = 0 to row = row
        self.operation_combo.current(0)
        row += 1

        # Text Input Box
        ttk.Label(self.root, text="Input Text:").grid(column=0, row=row, padx=10, pady=5, sticky='NW') #Input text label
        self.text_input = scrolledtext.ScrolledText(self.root, width=40, height=10, wrap=tk.WORD) #this helps us wrap text when typing in box
        self.text_input.grid(column=1, row=row, padx=10, pady=5) 
        row += 1
        
        # Action Button
        self.execute_btn = ttk.Button(self.root, text="Examine", command=self.Operaterw) #calls on the operatin wanted
        self.execute_btn.grid(column=1, row=row, padx=10, pady=5)
        row += 1
        
        # Results Display Box
        ttk.Label(self.root, text="Results:").grid(column=0, row=row, padx=10, pady=5, sticky='NW')
        self.results_display = scrolledtext.ScrolledText(self.root, width=40, height=10, wrap=tk.WORD, state='disabled')
        self.results_display.grid(column=1, row=row, padx=10, pady=5)
        
        # Submit button
        submit_button = ttk.Button(self.root, text="Save", command=lambda: self.store_inputs(entries))
        submit_button.grid(column=0, row=row+1, columnspan=2, padx=10, pady=10)


    def Operaterw(self):
        operation = self.operation.get()
        text = self.text_input.get("1.0", tk.END).strip()
        result = ""
        
        if operation == 'Sentiment Analysis':
            result = self.sentiment_analysis(text)
        elif operation == 'Word Frequency':
            #word frequency
            result = self.Word_Frequency(text)
        elif operation == 'Spelling Correction':
            result = self.spelling_correction(text)
        elif operation == 'Text Summarization':
            result = self.text_summarization(text)
        
        self.display_results(result)
    
    def sentiment_analysis(self, text):
        blob = TextBlob(text)
        sentiment = blob.sentiment
        return f"Sentiment polarity: {sentiment.polarity}, Sentiment subjectivity: {sentiment.subjectivity}"
    
    def Word_Frequency(self, text):
        blob = TextBlob(text)
        words = blob.words.lower()  # Convert to lowercase to ensure accurate frequency analysis
        word_freq = Counter(words)
        # Display the most common 3 words and their frequencies
        common_words = word_freq.most_common(3)
        return f"Word Frequencies:\n" + "\n".join([f"{word}: {freq}" for word, freq in common_words])
    
    def spelling_correction(self, text):
        blob = TextBlob(text)
        corrected = blob.correct()
        return f"Corrected text: {corrected}"
    
    def text_summarization(self, text):
        blob = TextBlob(text)
        sentences = blob.sentences
        summary = sentences[:2]  # Simple strategy: take the first two sentences as a summary
        return '\n'.join(str(sentence) for sentence in summary)
    
    def display_results(self, text):
        self.results_display.config(state='normal')
        self.results_display.delete('1.0', tk.END)
        self.results_display.insert('1.0', text)
        self.results_display.config(state='disabled')

    def store_inputs(self, entries):
        # Store entries from the entry widgets
        for label, var in entries.items():
            self.inputs_storage[label] = var.get()

        # Store the text input from the Text Input Box
        text_input_content = self.text_input.get("1.0", tk.END).strip()
        self.inputs_storage["Text Input"] = text_input_content

        # For demonstration, print the stored inputs
        print("Stored inputs:", self.inputs_storage)

def main():
    root = tk.Tk()
    app = MoodTrackerApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
